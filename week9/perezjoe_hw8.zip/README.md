To run the program "binpacking.py" type in the terminal the (python3 [filename.py]), so it would be "python3 binpacking.py".

Make sure to have a text file named "bin.txt" in the same repository as this file to run the program.