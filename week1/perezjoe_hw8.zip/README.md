Problem 4
To run these programs (insertsort.py, mergesort.py) in Python, you must type "python3 [filename.py]" on the command line.

Warning: Each time you run the program you must delete the previous .out file, or else all, including previous runs, results will append to the same file rather than being overwritten.

Problem 5
To run these programs (insertTime.py, mergeTime.py) in Python, you must type "python3 [filename.py]" on the command line.

Warning: You must manually hard code the sizes of the arrays you want running times for. In order to do so, you must change the "n" value in the main function to the size you want.