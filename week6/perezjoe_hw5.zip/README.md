To run this program (bfs_vs_hs.py) in Python, you must type "python3 [filename.py] [wrestler#.txt]" on the command line.

Warning: You must include a text file after the python file on the command line to run the program. Else, there will be an error stating there is a missing statment.